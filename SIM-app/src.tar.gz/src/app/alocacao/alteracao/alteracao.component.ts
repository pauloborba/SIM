import { NgModule } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Aula } from '../aula';

@Component({
  selector: 'app-root',
  templateUrl: './alteracao.component.html',
  styleUrls: ['./alteracao.component.css']
})
export class AlteracaoComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
    
  }
}
