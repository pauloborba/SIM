import { Component, OnInit } from '@angular/core';
import {Monitor} from '../monitor'
@Component({
  selector: 'app-root',
  templateUrl: './disponibilidade.component.html',
  styleUrls: ['./disponibilidade.component.css']
})
export class DisponibilidadeComponent implements OnInit {

  constructor() { }
  
  ngOnInit() {
    
  }

}