import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'alocacao',
    templateUrl: './alocacao.component.html'
    
  })
  export class AlocacaoComponent{}