export class Monitor {
    nome: string;
    disponibilidade: boolean[];
    restricoes: string[];
    alocacoes: number;
    chefe: boolean;
}