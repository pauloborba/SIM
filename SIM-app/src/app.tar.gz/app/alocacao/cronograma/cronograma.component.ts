import { Component, OnInit } from '@angular/core';
import { Aula } from '../aula';

@Component({
  selector: 'app-root',
  templateUrl: './cronograma.component.html',
  styleUrls: ['./cronograma.component.css']
})
export class CronogramaComponent implements OnInit {

  constructor() { }
  
  ngOnInit() {
    
  }

}
